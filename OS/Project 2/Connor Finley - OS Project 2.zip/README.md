# Project 2 - Semaphores Readme

> Connor Finley
>
> 2017/10/10

This readme file explains how to run the code for project 2 in Operating Systems that deals with semaphores.

- To run in bash command line in Linux:

```bash
# Navigate to directory containing the file, main.c
gcc main.c
./a.out
```
